package id.peers

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MemberAcquisitionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_member_acquisition)
    }
}
